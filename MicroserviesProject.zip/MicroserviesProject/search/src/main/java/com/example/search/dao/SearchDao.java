package com.example.search.dao;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.search.model.Train;
import com.example.search.model.TrainId;

@Repository
public interface SearchDao extends CrudRepository<Train, TrainId> {
	
	@Query(value = "(select * from train t where t.train_number= ?1)", nativeQuery = true)
	List<Train> findByTrainNumber(String trainNumber);
	
	@Query(value="(select * from train t where (t.from_place= ?1 and t.to_place= ?2 and t.date= ?3))", nativeQuery=true)
	List<Train> findByFromPlaceAndToPlaceAndDate(String fromPlace,String toPlace,LocalDate date);
}
