package com.example.search.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.search.dao.SearchDao;
import com.example.search.exception.StationNotFoundException;
import com.example.search.exception.TrainNumberNotFoundException;
import com.example.search.model.Train;

@Service
public class SearchService {
	List<Train> train=new ArrayList<Train>();
	@Autowired
	private SearchDao searchDao;

	public void addTrainDetails(Train train) {
		searchDao.save(train);
	}

	public List<Train> getTrainByTrainNumber(String trainNumber) {
	train=searchDao.findByTrainNumber(trainNumber);
	if(train.isEmpty()){
		throw new TrainNumberNotFoundException("Train Number not available");
	}
	return train;
	}
	public List<Train> getTrainByFromPlaceAndToPlaceAndDate(String fromPlace,String toPlace,LocalDate date) {
		train=searchDao.findByFromPlaceAndToPlaceAndDate(fromPlace, toPlace, date);
		if(train.isEmpty()){
			throw new StationNotFoundException("Station names are not available");
		}
		return train;

		}
}