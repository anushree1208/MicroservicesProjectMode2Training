package com.pack.IrctcUser.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.pack.IrctcUser.Dto.BookingDto;
import com.pack.IrctcUser.Dto.PassengerDto;

@Service
public class BookingAndCancelService {
	@Autowired
	RestTemplate restTemplate;

	public int bookTrainTicket(BookingDto bookingDto) {

		/* RestTemplate restTemplate2 = new RestTemplate(); */
		int bookId = restTemplate.postForObject("http://BOOKINGAPPLICATION/addBookingDetails", bookingDto,
				Integer.class);
		return bookId;
	}

	public void cancelTrainTicket(String pnrNumber) {
		/* RestTemplate restTemplate3 = new RestTemplate(); */
		Map<String, String> params = new HashMap<String, String>();
		params.put("PNRNumber", pnrNumber);
		restTemplate.delete("http://BOOKINGAPPLICATION/user/cancelTicket/{PNRNumber}", params);

	}

	public List<String> addPassenger(PassengerDto passengerDto) {
		/* RestTemplate restTemplate2 = new RestTemplate(); */
		List<String> pnrNumber = restTemplate.postForObject("http://BOOKINGAPPLICATION/addPassenger", passengerDto,
				List.class);
		return pnrNumber;
	}
}
