package com.pack.IrctcUser.controller;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.pack.IrctcUser.Dto.SearchDto;
import com.pack.IrctcUser.Dto.SearchDto1;
import com.pack.IrctcUser.Service.SearchService;

@RestController
public class SearchController {

	@Autowired
	private SearchService searchService;

	@GetMapping(value = "/user/train/get/{trainNumber}")
	public SearchDto getTrainByTrainNumber(@PathVariable("trainNumber") String trainNumber) {
		return searchService.getTrainFromTrainNumber(trainNumber);
	}

	@GetMapping(value = "/user/train/details/{fromPlace}/{toPlace}/{date}")
	public SearchDto1 getTrainByFromPlaceAndToPlcaeAndDate(@PathVariable(value = "fromPlace") String fromPlace,
			@PathVariable(value = "toPlace") String toPlace,
			@PathVariable(value = "date") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
		return searchService.getTrainByFromPlaceAndToPlcaeAndDate(fromPlace, toPlace, date);
	}

}
