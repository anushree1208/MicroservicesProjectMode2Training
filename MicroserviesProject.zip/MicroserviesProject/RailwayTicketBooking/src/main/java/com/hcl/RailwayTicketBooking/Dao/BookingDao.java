package com.hcl.RailwayTicketBooking.Dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.hcl.RailwayTicketBooking.model.Booking;
@Repository
public interface BookingDao extends CrudRepository<Booking,Integer>{
	@Query(value="SELECT MAX(booking_id) FROM Booking",nativeQuery=true)
	Integer findbymaxid();
	
	@Query(value="select * from booking b where b.booking_id= ?1",nativeQuery=true)
	Booking findByUserId(int bookingId);
	
	@Query(value="select b.train_number from booking b where b.booking_id= ?1",nativeQuery=true)
	String findTrainNumber(int bookingId);
}
