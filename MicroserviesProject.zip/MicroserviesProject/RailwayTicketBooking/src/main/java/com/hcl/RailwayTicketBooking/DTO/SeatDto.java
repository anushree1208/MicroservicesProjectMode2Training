package com.hcl.RailwayTicketBooking.DTO;

public class SeatDto {
	private int numberOfSeatsAvailable;

	public int getNumberOfSeatsAvailable() {
		return numberOfSeatsAvailable;
	}

	public void setNumberOfSeatsAvailable(int numberOfSeatsAvailable) {
		this.numberOfSeatsAvailable = numberOfSeatsAvailable;
	}
	
}
