package com.hcl.RailwayTicketBooking.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.hcl.RailwayTicketBooking.DTO.BookingDto;
import com.hcl.RailwayTicketBooking.DTO.PassengerDto;
import com.hcl.RailwayTicketBooking.DTO.SearchDto;
import com.hcl.RailwayTicketBooking.DTO.SeatDto;
import com.hcl.RailwayTicketBooking.Dao.BookingDao;
import com.hcl.RailwayTicketBooking.Dao.PassengerDao;
import com.hcl.RailwayTicketBooking.model.Booking;
import com.hcl.RailwayTicketBooking.model.Passenger;

@Service
public class BookingAndCancelService {
	@Autowired
	RestTemplate restTemplate;

	@Autowired
	BookingDao bookingDao;

	@Autowired
	PassengerDao passengerDao;
	List<String> pnrNumber = new ArrayList<String>();
	Passenger p = new Passenger();
	Booking bookingDetails = new Booking();
	PassengerDto passengerDto1 = new PassengerDto();

	public int addBooking(BookingDto book) {
		int bookingid1 = bookingDao.findbymaxid();

		System.out.println(bookingid1);

		bookingDetails.setBookingId(bookingid1 + 1);

		System.out.println(bookingid1 + 1);

		bookingDetails.setDate(book.getDate());

		bookingDetails.setTrainNumber(book.getTrainNumber());

		bookingDetails.setUserId(book.getUserId());

		bookingDetails.setStatus("confirmed");

		bookingDao.save(bookingDetails);

		return bookingDetails.getBookingId();

	}

	public void deletePassengerTicket(String pnrNumber) {
		Optional<Passenger> passengerDetails = passengerDao.findById(pnrNumber);
		passengerDao.deleteById(pnrNumber);
		int bookId = passengerDetails.get().getBookingId();
		Booking booking = bookingDao.findByUserId(bookId);
		booking.setNoOfSeatsBooked(booking.getNoOfSeatsBooked() - 1);

		if (booking.getNoOfSeatsBooked() != 0) {
			bookingDao.save(booking);
		} else {
			bookingDao.deleteById(booking.getBookingId());
		}
		int bookId1 = passengerDetails.get().getBookingId();
		String trainNumber = bookingDao.findTrainNumber(bookId1);
		/*RestTemplate restTemplate = new RestTemplate();*/
		Map<String, String> params = new HashMap<String, String>();
		params.put("trainNumber", trainNumber);
		SearchDto searchDto = restTemplate.getForObject("http://SEARCHAPPLICATION/train/{trainNumber}",
				SearchDto.class, params);
		SeatDto seatDto = new SeatDto();
		seatDto.setNumberOfSeatsAvailable(searchDto.getNumberOfSeatsAvailable() + 1);
		restTemplate.postForObject("http://SEARCHAPPLICATION/train/updateseat/{trainNumber}", seatDto, Integer.class,
				trainNumber);

	}

	public List<String> addPassengerDetails(PassengerDto passengerDto) {

		System.out.println("lkfjr");

		Booking booking = bookingDao.findById(passengerDto.getBookingId()).orElse(null);

		System.out.println(passengerDto.getPassenger().size());

		System.out.println(passengerDto.getPassenger().get(0).getPassengerName());

		for (int i = 0; i < passengerDto.getPassenger().size(); i++) {

			System.out.println("jghf");

			int randomthree = (int) ((Math.random() * 1000));

			int randomNumber = (int) ((Math.random() * 1000000));
			String

			PNRNumber = randomthree + "-" + randomNumber;

			p.setPNRNumber(PNRNumber);

			p.setPassengerName(passengerDto.getPassenger().get(i).getPassengerName());

			p.setAge(passengerDto.getPassenger().get(i).getAge());

			p.setBookingId(passengerDto.getBookingId());

			int seatNumber1 = passengerDao.findbymaxseatNumber();

			p.setSeatNumber(seatNumber1 + 1);

			System.out.println(seatNumber1);

			p.setUserId(passengerDto.getUserId());
			passengerDao.save(p);
			booking.setNoOfSeatsBooked(passengerDto.getPassenger().size());
			bookingDao.save(booking);
		}
		int bookId = p.getBookingId();
		String trainNumber = bookingDao.findTrainNumber(bookId);
		/*RestTemplate restTemplate = new RestTemplate();*/
		Map<String, String> params = new HashMap<String, String>();
		params.put("trainNumber", trainNumber);
		SearchDto searchDto = restTemplate.getForObject("http://SEARCHAPPLICATION/train/{trainNumber}",
				SearchDto.class, params);
		SeatDto seatDto = new SeatDto();
		seatDto.setNumberOfSeatsAvailable(searchDto.getNumberOfSeatsAvailable() - passengerDto.getPassenger().size());
		restTemplate.postForObject("http://SEARCHAPPLICATION/train/updateseat/{trainNumber}", seatDto, Integer.class,
				trainNumber);

		List<String> pnrNumber1 = passengerDao.findBybookingId(passengerDto.getBookingId());

		return pnrNumber1;

	}

}
